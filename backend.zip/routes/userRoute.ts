import express, { Request, Response, NextFunction } from 'express';
import { UserController } from '../controller/userController';
import upload from '../middleware/multer';

export const UserRouter = express.Router();

UserRouter.get('/users', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.getAllUsers(req, res, next);
});

UserRouter.get('/user', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.getUser(req, res, next);
});

UserRouter.get('/driver-users', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.getAllDrivers(req, res, next);
});

UserRouter.get('/driver-user/:id', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.getDriver(req, res, next);
});

UserRouter.post('/driver-verify/:id', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.verifyDriver(req, res, next);
});
UserRouter.post('/contacts/:id', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.createContacts(req, res);
});
UserRouter.post('/contacts/:id', async (req: Request, res: Response, next: NextFunction) => {
  await UserController.getUserContacts(req, res);
});
UserRouter.put('/update-user/:userId',upload.single("profile"), UserController.updateUser);