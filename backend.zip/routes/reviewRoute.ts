import { Router } from 'express';
import { 
  createReview, 
  getReviews, 
  getReviewById, 
  updateReview, 
  deleteReview 
} from '../controller/reviewController';

export const reviewRouter = Router();

// Define routes and their handlers
reviewRouter.post('/reviews', createReview);
reviewRouter.get('/reviews', getReviews);
reviewRouter.get('/reviews/:id', getReviewById);
reviewRouter.put('/reviews/:id', updateReview);
reviewRouter.delete('/reviews/:id', deleteReview);

