import express, { NextFunction, Request, Response } from "express";
import {
  LoginController,
  RegisterController,
} from "../controller/authController";
import upload from "../middleware/multer";

export const authRouter = express.Router();

authRouter.post(
  "/send-otp",
  async (req: Request, res: Response, next: NextFunction) => { 
    await LoginController.sendOtp(req, res, next);
  }
);

authRouter.post(
  "/validate-otp",
  async (req: Request, res: Response, next: NextFunction) => {
    await LoginController.validateOtp(req, res, next);
  }
);

authRouter.post(
  "/register",
  async (req: Request, res: Response, next: NextFunction) => {
    await RegisterController.register(req, res, next);
  }
);
authRouter.post(
  "/assign-vehicle",
  async (req: Request, res: Response, next: NextFunction) => {
    await RegisterController.assignVehicleToUser(req, res);
  }
);
authRouter.post(
  "/get-vehicle",
  async (req: Request, res: Response, next: NextFunction) => {
    await RegisterController.getVehiclesOfUser(req, res);
  }
);

authRouter.post(
  "/driver-register",
  upload.fields([
    { name: "rc", maxCount: 1 },
    { name: "driverlicence", maxCount: 1 },
  ]),
  async (req: Request, res: Response, next: NextFunction) => {
    await RegisterController.driverRegister(req, res, next);
  }
);

export default authRouter;
