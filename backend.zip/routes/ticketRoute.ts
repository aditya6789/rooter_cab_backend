import { Router } from 'express';
import { createTicket, getTickets, getTicketById, updateTicket, deleteTicket } from '../controller/ticketController';

export const ticketRouter: Router = Router();

ticketRouter.post('/tickets', createTicket);
ticketRouter.get('/tickets', getTickets);
ticketRouter.get('/tickets/:id', getTicketById);
ticketRouter.put('/tickets/:id', updateTicket);
ticketRouter.delete('/tickets/:id', deleteTicket);


