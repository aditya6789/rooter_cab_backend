import { Router } from 'express';
import WalletController from '../controller/walletController';

const WalletRouter = Router();


WalletRouter.get('/wallet/:driverId',WalletController.getWallet );


export default WalletRouter;
