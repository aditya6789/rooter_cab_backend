import { Router } from 'express';
import { createNotification, getNotifications, getNotificationById, updateNotification, deleteNotification } from '../controller/notificationController';

export const notificationRouter = Router();

notificationRouter.post('/notifications', createNotification);
notificationRouter.get('/notifications', getNotifications);
notificationRouter.get('/notifications/:id', getNotificationById);
notificationRouter.put('/notifications/:id', updateNotification);
notificationRouter.delete('/notifications/:id', deleteNotification);

