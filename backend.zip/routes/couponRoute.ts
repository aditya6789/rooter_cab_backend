import { Router } from "express";
import {
  createCoupon,
  getCoupons,
  getCouponById,
  updateCoupon,
  deleteCoupon,
} from "../controller/couponController";

const couponRouter = Router();

couponRouter.post("/coupons", createCoupon);
couponRouter.get("/coupons", getCoupons);
couponRouter.get("/coupons/:id", getCouponById);
couponRouter.put("/coupons/:id", updateCoupon);
couponRouter.delete("/coupons/:id", deleteCoupon);

export default couponRouter;
