import multer, { Multer, FileFilterCallback } from 'multer';
import path from 'path';
import { Request } from 'express';

// Configure storage
const storage = multer.diskStorage({
  destination: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) {
    cb(null, 'public/uploads/'); // Specify the destination directory for file uploads
  },
  filename: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) {
    cb(null, Date.now() + path.extname(file.originalname)); // Set the file name
  },
});

// File filter for validating file types
const fileFilter = (req: Request, file: Express.Multer.File, cb: FileFilterCallback): void => {
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

// Initialize multer with the storage and file filter
const upload: Multer = multer({
  storage: storage,
  fileFilter: fileFilter,
});

export default upload;
