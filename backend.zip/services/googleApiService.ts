import axios, { AxiosResponse } from "axios";

const kGoogleApiKey = "AIzaSyCdXyAkWjkhUlWXBbpkieWRi2OV47AbVFE";

interface Route {
  duration: string;
  distanceMeters: number;
  travelAdvisory?: {
    tollInfo?: {
      estimatedPrice?: [
        {
          currencyCode: string;
          units: number;
        }
      ];
    };
  };
}

interface DirectionsResponse {
  routes: Route[];
}

export async function getDirectionsWithTolls(
  pickupLat: number,
  pickupLong: number,
  dropLat: number,
  dropLong: number
): Promise<{
  duration?: string;
  distance?: number;
  tollCost?: number;
  currency?: string;
  error?: string;
}> {
  try {
    const response: AxiosResponse<DirectionsResponse> = await axios.post(
      "https://routes.googleapis.com/directions/v2:computeRoutes",
      {
        origin: {
          location: {
            latLng: {
              latitude: pickupLat,
              longitude: pickupLong,
            },
          },
        },
        destination: {
          location: {
            latLng: {
              latitude: dropLat,
              longitude: dropLong,
            },
          },
        },
        travelMode: "DRIVE",
        extraComputations: ["TOLLS"],
        routeModifiers: {
          vehicleInfo: {
            emissionType: "GASOLINE",
          },
          tollPasses: ["IN_FASTAG"],
        },
      },
      {
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": kGoogleApiKey,
          "X-Goog-FieldMask":
            "routes.duration,routes.distanceMeters,routes.travelAdvisory.tollInfo",
        },
      }
    );

    if (response.status === 200) {
      const data = response.data;
      console.log(data);
      if (data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        const tollInfo = route.travelAdvisory?.tollInfo || {};
        const estimatedPrice = tollInfo.estimatedPrice;

        const tollCost =
          estimatedPrice && estimatedPrice.length > 0
            ? estimatedPrice[0].units
            : 0;
        const currency =
          estimatedPrice && estimatedPrice.length > 0
            ? estimatedPrice[0].currencyCode
            : "INR";

        return {
          duration: route.duration,
          distance: route.distanceMeters,
          tollCost,
          currency,
        };
      } else {
        return { error: "No route found" };
      }
    } else {
      throw new Error(
        `Failed to load directions. Status code: ${response.status}`
      );
    }
  } catch (error) {
    console.error(`Error getting directions with tolls: ${error}`);
    return { error: "Error fetching data" };
  }
}
