import Joi from "joi";
import { Request, Response, NextFunction } from "express";
import Otp from "../models/otpModel";
import User from "../models/userModel";
import Refresh from "../models/refreshModel";
import CustomErrorHandler from "../services/customErrorHandler";
import JwtService from "../services/jwtService";
import { REFRESH_SECRET } from "../config/index";
import {
  sendOtpSchema,
  validateOtpSchema,
  registerSchema,
  driverRegisterSchema,
} from "../schema/auth.schema";

import {
  Make,
  Vehicle,
  VehicleCategory,
  VehicleModel,
} from "../models/vechileModel";
import { failureResponse, successResponse } from "../utils/response";

// Function to generate a 6-digit numeric OTP
const generateNumericOtp = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

export const LoginController = {
  async sendOtp(req: Request, res: Response, next: NextFunction) {
    console.log("OTP SEND CALLED");
    const { error } = sendOtpSchema.validate(req.body);
    if (error) {
      return next(error);
    }

    const { phone } = req.body;
    const otp = generateNumericOtp();

    try {
      // Store OTP in the database (you might want to set an expiration time)
      await Otp.create({ phone, otp, createdAt: new Date() });

      // Return OTP for simplicity (in real-world scenarios, send this via SMS)
      res.send({ message: "OTP sent successfully.", otp });
    } catch (err) {
      return next(err);
    }
  },

  // Validate OTP and redirect to registration if new user
  async validateOtp(req: Request, res: Response, next: NextFunction) {
    const { error } = validateOtpSchema.validate(req.body);

    if (error) {
      return next(error);
    }

    const { phone, otp } = req.body;

    try {
      // Check if the OTP is valid
      const otpRecord = await Otp.findOne({ phone, otp });

      if (!otpRecord) {
        return next(CustomErrorHandler.wrongCredentials());
      }

      // Check if the user exists
      let user = await User.findOne({ phone });

      if (!user) {
        // If the user does not exist, add phone number to temporary storage and redirect to registration
        return res
          .status(201)
          .send({ message: "New user. Please register.", phone });
      }

      // Generate tokens
      const access_token = JwtService.sign({
        _id: user._id,
        role: user.userType,
      });
      const refresh_token = JwtService.sign(
        { _id: user._id, role: user.userType },
        "1y",
        REFRESH_SECRET
      );
      await Refresh.create({ token: refresh_token });

      // Remove the OTP after successful validation
      await Otp.deleteOne({ phone, otp });

      res.send({
        access_token,
        refresh_token,
        role: user.userType,
        phone: user.phone,
        user,
      });
    } catch (err) {
      return next(err);
    }
  },
};

// Controller for User Registration
export const RegisterController = {
  async register(req: Request, res: Response, next: NextFunction) {
    const { error } = registerSchema.validate(req.body);

    if (error) {
      return next(error);
    }

    const { full_name, email, phone } = req.body;

    try {
      // Check if the user already exists
      let user = await User.findOne({ phone });

      if (user) {
        return next(CustomErrorHandler.alreadyExist("User already exists."));
      }

      // Create the new user
      user = new User({ full_name, email, phone });
      await user.save();

      res.send({ message: "User registered successfully." });
    } catch (err) {
      return next(err);
    }
  },

  async driverRegister(req: Request, res: Response, next: NextFunction) {
    try {
      // Ensure `req.files` is of the expected type
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };

      // Extract filenames from the uploaded files
      const rcFilename = files?.rc?.[0]?.filename ?? "";
      const driverLicenceFilename = files?.driverlicence?.[0]?.filename ?? "";

      // Log the filenames for debugging
      console.log("RC Filename:", rcFilename);
      console.log("Driving Licence Filename:", driverLicenceFilename);

      // Ensure file paths are set in the request body before validation
      req.body.rc = rcFilename;
      req.body.driverlicence = driverLicenceFilename;

      console.log("Body after adding files:", req.body); // Log the body after adding file paths

      // Validate the request body
      const { error } = driverRegisterSchema.validate(req.body);
      if (error) {
        console.log("Validation error:", error.details);
        return next(error);
      }

      const { full_name, email, aadharcard, pancard, phone } = req.body;
      const userType = "driver";

      // Check if the user already exists
      let user = await User.findOne({ email });
      if (user) {
        return next(CustomErrorHandler.alreadyExist("User already exists."));
      }

      // Create the new user
      user = new User({
        full_name,
        email,
        phone,
        aadharcard,
        userType,
        pancard,
        rc: rcFilename,
        driverlicence: driverLicenceFilename,
      });
      await user.save();
      console.log("saved");

      res.send({
        user,
        message: "driver register successfully",
      });
    } catch (err) {
      return next(err);
    }
  },

  async assignVehicleToUser(req: Request, res: Response) {
    const { model, userId } = req.body;
    console.log(req.body);
    const vehicleModel = await VehicleModel.findById(model);
    const user = await User.findById(userId);
    // const make =  await Make.findById(makeId);
    // const category =  await VehicleCategory.findById(categoryId);

    if (!vehicleModel) {
      return res.status(400).json(failureResponse("Invalid Model"));
    }
    if (!user) {
      return res.status(400).json(failureResponse("Invalid User"));
    }
    const vehicle = new Vehicle({
      model: model,

      user: userId,
    });

    vehicle.save();
    return res
      .status(200)
      .json(successResponse("Assigned Successfully", vehicle));
  },

  async getVehiclesOfUser(req: Request, res: Response) {
    const { userId } = req.body;
    console.log(req.body);

    try {
      const vehicles = await Vehicle.find({ user: userId }).populate("model");

      if (!vehicles || vehicles.length === 0) {
        return res.status(404).json(failureResponse("No Vehicles Found"));
      }

      return res
        .status(200)
        .json(successResponse("Vehicles Retrieved Successfully", vehicles));
    } catch (error) {
      console.error(error);
      return res.status(500).json(failureResponse("Server Error"));
    }
  },
};
