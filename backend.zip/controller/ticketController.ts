import { Request, Response } from 'express';
import Ticket, { ITicket } from '../models/ticketModel';

const createTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const ticket: ITicket = new Ticket(req.body);
    await ticket.save();
    res.status(201).json(ticket);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

const getTickets = async (req: Request, res: Response): Promise<void> => {
  try {
    const tickets: ITicket[] = await Ticket.find();
    res.status(200).json(tickets);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

const getTicketById = async (req: Request, res: Response): Promise<void> => {
  try {
    const ticket: ITicket | null = await Ticket.findById(req.params.id);
    if (ticket) {
      res.status(200).json(ticket);
    } else {
      res.status(404).json({ message: 'Ticket not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

const updateTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const ticket: ITicket | null = await Ticket.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (ticket) {
      res.status(200).json(ticket);
    } else {
      res.status(404).json({ message: 'Ticket not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

const deleteTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const ticket: ITicket | null = await Ticket.findByIdAndDelete(req.params.id);
    if (ticket) {
      res.status(200).json({ message: 'Ticket deleted' });
    } else {
      res.status(404).json({ message: 'Ticket not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export { createTicket, getTickets, getTicketById, updateTicket, deleteTicket };
