import { Request, Response } from 'express';
import Coupon, { ICoupon } from '../models/couponModel';

const createCoupon = async (req: Request, res: Response): Promise<void> => {
  try {
    const coupon: ICoupon = new Coupon(req.body);
    await coupon.save();
    res.status(201).json(coupon);
  } catch (error:any) {
    res.status(400).json({ message: error.message });
  }
};

const getCoupons = async (req: Request, res: Response): Promise<void> => {
  try {
    const coupons: ICoupon[] = await Coupon.find();
    res.status(200).json(coupons);
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const getCouponById = async (req: Request, res: Response): Promise<void> => {
  try {
    const coupon: ICoupon | null = await Coupon.findById(req.params.id);
    if (coupon) {
      res.status(200).json(coupon);
    } else {
      res.status(404).json({ message: 'Coupon not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const updateCoupon = async (req: Request, res: Response): Promise<void> => {
  try {
    const coupon: ICoupon | null = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (coupon) {
      res.status(200).json(coupon);
    } else {
      res.status(404).json({ message: 'Coupon not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const deleteCoupon = async (req: Request, res: Response): Promise<void> => {
  try {
    const coupon: ICoupon | null = await Coupon.findByIdAndDelete(req.params.id);
    if (coupon) {
      res.status(200).json({ message: 'Coupon deleted' });
    } else {
      res.status(404).json({ message: 'Coupon not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

export { createCoupon, getCoupons, getCouponById, updateCoupon, deleteCoupon };
