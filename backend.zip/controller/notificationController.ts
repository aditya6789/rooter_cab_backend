import { Request, Response } from 'express';
import Notification, { INotification } from '../models/notificationModel';

const createNotification = async (req: Request, res: Response): Promise<void> => {
  try {
    const notification: INotification = new Notification(req.body);
    await notification.save();
    res.status(201).json(notification);
  } catch (error:any) {
    res.status(400).json({ message: error.message });
  }
};

const getNotifications = async (req: Request, res: Response): Promise<void> => {
  try {
    const notifications: INotification[] = await Notification.find();
    res.status(200).json(notifications);
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const getNotificationById = async (req: Request, res: Response): Promise<void> => {
  try {
    const notification: INotification | null = await Notification.findById(req.params.id);
    if (notification) {
      res.status(200).json(notification);
    } else {
      res.status(404).json({ message: 'Notification not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const updateNotification = async (req: Request, res: Response): Promise<void> => {
  try {
    const notification: INotification | null = await Notification.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (notification) {
      res.status(200).json(notification);
    } else {
      res.status(404).json({ message: 'Notification not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

const deleteNotification = async (req: Request, res: Response): Promise<void> => {
  try {
    const notification: INotification | null = await Notification.findByIdAndDelete(req.params.id);
    if (notification) {
      res.status(200).json({ message: 'Notification deleted' });
    } else {
      res.status(404).json({ message: 'Notification not found' });
    }
  } catch (error:any) {
    res.status(500).json({ message: error.message });
  }
};

export { createNotification, getNotifications, getNotificationById, updateNotification, deleteNotification };
