import { Request, Response } from "express";
import Wallet from "../models/walletModel";

const WalletController = {
    async getWallet (req:Request, res:Response)  {

        
        try {
          const { driverId } = req.params;

          console.log(driverId);
      
          // Find the wallet by driverId
          const wallet = await Wallet.findOne({driverId:driverId});

      
          if (!wallet) {
            console.log("wallet not found");
            return res.status(404).json({ message: 'Wallet not found' });
          }
      
          res.json(wallet);
        } catch (error) {
          console.error(error);
          res.status(500).json({ message: 'Server Error' });
        }
      }
}

export  default WalletController;