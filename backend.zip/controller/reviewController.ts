import { Request, Response } from 'express';
import Review, { IReview } from '../models/reviewModel';

// Create a review
const createReview = async (req: Request, res: Response): Promise<void> => {
  try {
    const review: IReview = new Review(req.body);
    await review.save();
    res.status(201).json(review);
    console.log(review);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

// Get all reviews
const getReviews = async (req: Request, res: Response): Promise<void> => {
  try {
    const reviews: IReview[] = await Review.find()
      .populate('reviewer')
      .populate('reviewee');
    res.status(200).json(reviews);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Get a review by ID
const getReviewById = async (req: Request, res: Response): Promise<void> => {
  try {
    const review: IReview | null = await Review.findById(req.params.id)
      .populate('reviewer')
      .populate('reviewee');
    if (review) {
      res.status(200).json(review);
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Update a review by ID
const updateReview = async (req: Request, res: Response): Promise<void> => {
  try {
    const review: IReview | null = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (review) {
      res.status(200).json(review);
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a review by ID
const deleteReview = async (req: Request, res: Response): Promise<void> => {
  try {
    const review: IReview | null = await Review.findByIdAndDelete(req.params.id);
    if (review) {
      res.status(200).json({ message: 'Review deleted' });
    } else {
      res.status(404).json({ message: 'Review not found' });
    }
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

export { createReview, getReviews, getReviewById, updateReview, deleteReview };
