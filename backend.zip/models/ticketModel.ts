import mongoose, { Schema, Document } from 'mongoose';

export interface ITicket extends Document {
  title: string;
  description: string;
  createdBy: string;
  status: string;
  createdAt: Date;
}

const ticketSchema = new Schema<ITicket>({
  title: { type: String, required: true },
  description: { type: String, required: true },
  createdBy: { type: String, required: true },
  status: { type: String, default: 'open' },
  createdAt: { type: Date, default: Date.now }
});

const Ticket = mongoose.model<ITicket>('Ticket', ticketSchema);

export default Ticket;
