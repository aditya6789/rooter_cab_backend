import mongoose, { Schema, Document, Types, ObjectId } from 'mongoose';

interface ITransaction {
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  date: Date;
}

export interface IWallet extends Document {
  driverId: mongoose.Schema.Types.ObjectId;
  balance: number; // Use the primitive 'number' type here
  currency: string;
  transactions:Types.Array<ITransaction>;
}

const WalletSchema: Schema = new Schema({
  driverId: {  type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true },
  balance: { type: Number, default: 0 }, // Use 'Number' in Mongoose Schema but 'number' in TypeScript interface
  currency: { type: String, default: 'USD' },
  transactions: [
    {
      amount: { type: Number, required: true },
      type: { type: String, required: true },
      description: { type: String, required: true },
      date: { type: Date, default: Date.now },
    },
  ],
});

const Wallet = mongoose.model<IWallet>('Wallet', WalletSchema);
export default Wallet;
