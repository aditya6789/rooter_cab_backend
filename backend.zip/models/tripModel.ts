import { required } from "joi";
import { Schema, model, Document, Types } from "mongoose";

export interface ITrip extends Document {
    rideId:string;
  driverName: string;
  customerName?: string;
  pickupLocation: {
    latitude?: number;
    longitude?: number;
    address?: string;
  };
  dropLocation: {
    latitude?: number;
    longitude?: number;
    address?: string;
  };
  userType?: string;
  tripCompleted:Boolean;
}

const tripSchema = new Schema({
  driverName: { type: String, required: true },
  rideId:{type:String , required:true},
  customerName: { type: String },
  pickupLocation: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
    address: { type: String, required: true },
  },
  dropLocation: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
    address: { type: String, required: true },
  },
  userType: { type: String },
  tripCompleted:{type:Boolean , default:false},
});

const Trip = model<ITrip>("Trip", tripSchema);
export default Trip;
