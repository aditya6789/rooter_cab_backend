import { Schema, model, Document, Types } from "mongoose";
export interface IContact {
  name: string;
  phoneNumber: string;
}

interface IUser extends Document {
  full_name: string;
  email: string;
  phone?: string;
  gender?:string;
  vehicle?: string;
  verified: boolean;
  aadharcard?: string;
  pancard?: string;
  profile?:string;
  rc?: string;
  driverlicence?: string;
  contacts?:IContact[];
  userType: "customer" | "driver";
  trips: Types.ObjectId[]; // Only ObjectId array
  vehicles: Types.ObjectId; // ObjectId array for vehicles
}
const ContactSchema = new Schema<IContact>({
  name: { type: String, required: true },
  phoneNumber: { type: String, required: true },
}); 
const UserSchema = new Schema<IUser>({
  full_name: {
    type: String,
    required: true,
    maxlength: 50,
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  phone: {
    type: String,
  },
  gender:{
    type:String,
    required:false
  },
  vehicle: {
    type: String,
  },
  verified: {
    type: Boolean,
    default: false,
  },
  aadharcard: {
    type: String,
  },
  profile:{
    type:String,
   
  },
  pancard: {
    type: String,
  },
  rc: {
    type: String,
  },
  driverlicence: {
    type: String,
  },
  contacts: [ContactSchema],
  userType: {
    type: String,
    enum: ["customer", "driver"],
    required: true,
    default: "customer",
  },
  trips: [{ type: Schema.Types.ObjectId, ref: "Trip" }], // Reference to Trip model
  vehicles: { type: Schema.Types.ObjectId, ref: "VehicleModel" } // Reference to Vehicle model
});

const User = model<IUser>("User", UserSchema);

export default User;
