import mongoose, { Document, Schema } from 'mongoose';

export interface IReview extends Document {
  reviewer: mongoose.Schema.Types.ObjectId;
  reviewerModel: 'User' | 'Driver';
  reviewee: mongoose.Schema.Types.ObjectId;
  revieweeModel: 'User' | 'Driver';
  rating: number;
  comment: string;
  createdAt: Date;
}

const reviewSchema: Schema = new Schema({
  reviewer: { type: Schema.Types.ObjectId, refPath: 'reviewerModel', required: true },
  reviewerModel: { type: String, required: true, enum: ['User', 'Driver'] },
  reviewee: { type: Schema.Types.ObjectId, refPath: 'revieweeModel', required: true },
  revieweeModel: { type: String, required: true, enum: ['User', 'Driver'] },
  rating: { type: Number, required: true },
  comment: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

const Review = mongoose.model<IReview>('Review', reviewSchema);

export default Review;
